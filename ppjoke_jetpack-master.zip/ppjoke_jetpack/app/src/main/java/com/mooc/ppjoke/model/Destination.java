package com.mooc.ppjoke.model;

public class Destination {
    public String pageUrl;
    public int id;
    public boolean needLogin;
    public boolean asStarter;
    public boolean isFragment;
    public String className;
}
