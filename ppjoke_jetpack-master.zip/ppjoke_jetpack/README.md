# ppjoke
jetpack 客户端
## [开发笔记](https://git.imooc.com/coding-402/ppjoke_jetpack/src/master/jetpack%e5%ae%a2%e6%88%b7%e7%ab%af%e5%bc%80%e5%8f%91%e7%ac%94%e8%ae%b0.md)

## [服务器&数据库配置文档](<https://git.imooc.com/coding-402/ppjoke_jetpack/src/master/%e6%9c%8d%e5%8a%a1%e5%99%a8%e7%8e%af%e5%a2%83%e6%90%ad%e5%bb%ba.md>)

