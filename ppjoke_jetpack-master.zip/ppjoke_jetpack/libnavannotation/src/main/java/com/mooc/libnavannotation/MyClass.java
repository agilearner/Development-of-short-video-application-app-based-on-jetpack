package com.mooc.libnavannotation;

public class MyClass {
}
