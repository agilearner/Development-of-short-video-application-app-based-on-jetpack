该仓库是本课程的服务器项目源码

由于服务器已经部署到公网了，所以同学们可以选择性的在本地搭建项目服务器。
[本地服务器环境搭建教程文档](https://git.imooc.com/coding-402/ppjoke_jetpack/src/master/%e6%9c%8d%e5%8a%a1%e5%99%a8%e7%8e%af%e5%a2%83%e6%90%ad%e5%bb%ba.md)